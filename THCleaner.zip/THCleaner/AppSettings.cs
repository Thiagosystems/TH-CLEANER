using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace THCleaner
{
    public class AppSettings
    {
        // Aparência
        public string Theme { get; set; } = "dark";
        public string AccentA { get; set; } = "#22D3EE";
        public string AccentB { get; set; } = "#8B5CF6";
        public bool LogoUseAccent { get; set; } = false;
        public string LogoPrimary { get; set; } = "#E10600";
        public string LogoSecondary { get; set; } = "#E6E6E6";

        // Limpeza
        public int TempMinAgeHours { get; set; } = 24;
        public bool CloseBrowsers { get; set; } = false;
        public bool ConfirmClean { get; set; } = true;
        public Dictionary<string, bool> CategoryState { get; set; } = new();
        public List<string> Exclusions { get; set; } = new();

        // Arquivos grandes
        public bool LargeToRecycle { get; set; } = true;
        public int LargeMinMB { get; set; } = 500;
        public string LargeFolder { get; set; } = "";

        // Desinstalador
        public bool RestorePoint { get; set; } = true;
        public bool BackupRegistry { get; set; } = true;
        public bool ShowSystem { get; set; } = false;
        public bool QuietUninstall { get; set; } = false;
        public bool LeftoversToRecycle { get; set; } = true;

        public static string DataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "THCleaner");
        public static string BackupDir => Path.Combine(DataDir, "Backups");
        static string FilePath => Path.Combine(DataDir, "settings.json");

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
                    s.CategoryState ??= new();
                    s.Exclusions ??= new();
                    return s;
                }
            }
            catch { }
            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }
    }
}
