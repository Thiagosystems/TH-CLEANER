using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace THCleaner
{
    public class BigFile : Observable
    {
        bool _isChecked;
        public string Path { get; init; } = "";
        public string Name => System.IO.Path.GetFileName(Path);
        public string Folder => System.IO.Path.GetDirectoryName(Path) ?? "";
        public long Size { get; init; }
        public DateTime Modified { get; init; }
        public string SizeText => Fmt.Size(Size);
        public string DateText => Modified.ToString("dd/MM/yyyy");
        public string Extension => System.IO.Path.GetExtension(Path).TrimStart('.').ToUpperInvariant();
        public bool IsChecked { get => _isChecked; set => Set(ref _isChecked, value); }
    }

    public static class LargeFiles
    {
        public static readonly Dictionary<string, string[]> Types = new()
        {
            ["Todos"] = Array.Empty<string>(),
            ["Vídeos"] = new[] { ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".ts" },
            ["Instaladores e ISO"] = new[] { ".iso", ".img", ".exe", ".msi", ".msix", ".appx", ".vhd", ".vhdx" },
            ["Compactados"] = new[] { ".zip", ".rar", ".7z", ".tar", ".gz", ".xz", ".bz2" },
            ["Imagens e áudio"] = new[] { ".jpg", ".jpeg", ".png", ".psd", ".raw", ".cr2", ".nef", ".tif", ".tiff", ".wav", ".flac", ".mp3" },
        };

        /// <summary>Procura arquivos maiores que minBytes. Retorna no máximo 'limit' itens, do maior para o menor.</summary>
        public static List<BigFile> Scan(string root, long minBytes, string type, IProgress<string>? progress, CancellationToken ct, int limit = 500)
        {
            var exts = Types.TryGetValue(type, out var e) ? e : Array.Empty<string>();
            var found = new List<BigFile>();
            var options = new EnumerationOptions
            {
                RecurseSubdirectories = true,
                IgnoreInaccessible = true,
                AttributesToSkip = FileAttributes.ReparsePoint | FileAttributes.Offline
            };

            int scanned = 0;
            IEnumerable<string> files;
            try { files = Directory.EnumerateFiles(root, "*", options); }
            catch { return found; }

            using var it = files.GetEnumerator();
            while (true)
            {
                if (ct.IsCancellationRequested) break;
                string path;
                try { if (!it.MoveNext()) break; path = it.Current; }
                catch { break; }

                scanned++;
                if (scanned % 2000 == 0) progress?.Report($"{scanned:N0} arquivos verificados... {found.Count} encontrados");

                if (exts.Length > 0 && !exts.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase)) continue;
                try
                {
                    var fi = new FileInfo(path);
                    if (fi.Length >= minBytes)
                        found.Add(new BigFile { Path = path, Size = fi.Length, Modified = fi.LastWriteTime });
                }
                catch { }
            }

            progress?.Report($"{scanned:N0} arquivos verificados");
            return found.OrderByDescending(f => f.Size).Take(limit).ToList();
        }
    }
}
