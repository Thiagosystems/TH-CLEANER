using System.Threading;
using System.Windows;

namespace THCleaner
{
    public partial class App : Application
    {
        Mutex? _mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _mutex = new Mutex(true, "THCleaner_SingleInstance", out bool created);
            if (!created) { Shutdown(); return; }

            var settings = AppSettings.Load();
            ThemeManager.Apply(settings);

            var window = new MainWindow(settings);
            MainWindow = window;
            window.Show();
        }
    }
}
