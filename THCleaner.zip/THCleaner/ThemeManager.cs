using System;
using System.Windows;
using System.Windows.Media;

namespace THCleaner
{
    internal static class ThemeManager
    {
        public static readonly (string Name, string A, string B)[] Presets =
        {
            ("Neon",       "#22D3EE", "#8B5CF6"),
            ("Oceano",     "#3B82F6", "#06B6D4"),
            ("Esmeralda",  "#10B981", "#84CC16"),
            ("Pôr do sol", "#F59E0B", "#EF4444"),
            ("Rosa",       "#EC4899", "#8B5CF6"),
            ("Vermelho",   "#EF4444", "#B91C1C"),
            ("Dourado",    "#FACC15", "#F97316"),
            ("Gelo",       "#E0F2FE", "#94A3B8"),
        };

        public static void Apply(AppSettings s)
        {
            //            Bg         Card       Borda      Trilho     Texto      Apagado    Anel       Hover
            string[] t = s.Theme switch
            {
                "light" => new[] { "#F3F4F8", "#FFFFFF", "#E2E5EE", "#D9DDE8", "#1A1D2B", "#6B7190", "#E6E9F2", "#14000000" },
                "black" => new[] { "#000000", "#0B0B0B", "#1C1C1C", "#2A2A2A", "#F5F5F5", "#8A8A8A", "#181818", "#22FFFFFF" },
                _       => new[] { "#0B0E1A", "#141829", "#22273D", "#2A3050", "#E8EAF6", "#8A90B0", "#1E2338", "#22FFFFFF" },
            };

            var r = Application.Current.Resources;
            r["BgBrush"] = Solid(t[0]);
            r["CardBrush"] = Solid(t[1]);
            r["CardBorderBrush"] = Solid(t[2]);
            r["TrackBrush"] = Solid(t[3]);
            r["TextBrush"] = Solid(t[4]);
            r["MutedBrush"] = Solid(t[5]);
            r["RingBrush"] = Solid(t[6]);
            r["HoverBrush"] = Solid(t[7]);

            Color a = Parse(s.AccentA, "#22D3EE"), b = Parse(s.AccentB, "#8B5CF6");
            r["AccentBrush"] = new LinearGradientBrush(a, b, new Point(0, 0), new Point(1, 1));
            r["AccentSolidBrush"] = new SolidColorBrush(b);
            r["AccentColorA"] = a;
            r["AccentColorB"] = b;

            r["LogoPrimaryBrush"] = s.LogoUseAccent
                ? new LinearGradientBrush(a, b, new Point(0, 0), new Point(1, 1))
                : new SolidColorBrush(Parse(s.LogoPrimary, "#E10600"));
            string sec = s.LogoSecondary;
            if (s.Theme == "light" && string.Equals(sec, "#E6E6E6", StringComparison.OrdinalIgnoreCase))
                sec = "#3A3F55";
            r["LogoSecondaryBrush"] = new SolidColorBrush(Parse(sec, "#E6E6E6"));
        }

        public static Color Parse(string? hex, string fallback)
        {
            try { return (Color)ColorConverter.ConvertFromString(hex!); }
            catch { return (Color)ColorConverter.ConvertFromString(fallback); }
        }

        public static bool TryParse(string text, out string normalized)
        {
            normalized = "";
            text = text.Trim();
            if (!text.StartsWith("#")) text = "#" + text;
            try
            {
                var c = (Color)ColorConverter.ConvertFromString(text);
                normalized = $"#{c.R:X2}{c.G:X2}{c.B:X2}";
                return true;
            }
            catch { return false; }
        }

        static SolidColorBrush Solid(string hex) => new((Color)ColorConverter.ConvertFromString(hex));
    }
}
