<p align="center">
  <img src="docs/logo.png" alt="TH Cleaner" width="220">
</p>

<h1 align="center">TH Cleaner</h1>

<p align="center">
  Disk cleaner and complete uninstaller for Windows, with leftover removal and registry backup.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Windows-10%20%7C%2011-0078D6?logo=windows" alt="Windows">
  <img src="https://img.shields.io/badge/.NET-8-512BD4?logo=dotnet" alt=".NET 8">
  <img src="https://img.shields.io/badge/license-MIT-green" alt="MIT License">
</p>

<p align="center"><a href="LEIAME.md">🇧🇷 Leia em português</a></p>

---

## ✨ Features

### 🧹 Disk cleanup
- **Windows**: user and system temp files, Recycle Bin, thumbnail cache, Windows Update cache, Delivery Optimization, error reports, memory dumps, old logs, shader cache, Prefetch, recent files and DNS cache
- **Browsers**: Chrome, Edge, Brave, Vivaldi, Opera, Opera GX and Firefox (cache, cookies and history separately), across all profiles
- **Apps**: Discord, Spotify, Steam, Epic Games, Teams, VS Code and developer caches (npm, pip, NuGet)
- **Analyze before cleaning**: see how much space each item uses
- Only shows the browsers and apps that are installed on your PC
- Warnings on items with side effects (e.g. clearing cookies logs you out of websites)
- Option to close open browsers and apps automatically
- Temp files are only deleted after X hours (configurable)
- **Exclusion list**: folders that will never be deleted
- Files in use are safely skipped

### 📦 Large files
- Search any folder or drive for files from 50 MB up to 10 GB
- Filter by type: videos, installers/ISO, archives, images/audio
- Open the file location, select several and delete them (to the Recycle Bin or permanently)

### 🗑️ Complete uninstaller
- Lists every installed program with icon, publisher, version, date and size
- Search and sort by name, size, date or publisher
- **Uninstall + leftover scan**: after the program's uninstaller runs, finds the folders, shortcuts and registry keys left behind
- **Forced removal** for programs with a broken uninstaller
- **Batch uninstall**: select several programs and they're removed one after another
- Silent uninstall when the program supports it
- Items whose name matches the program are pre-selected; similar ones are left for you to decide
- Safeguards: never deletes system folders, and selects nothing automatically if another program has the same name or uses the same folder
- Open the install folder, open the key in Registry Editor or search the program on the web
- Export the program list to CSV or TXT

### 🛍️ Microsoft Store apps
- Lists Store apps and Windows preinstalled apps
- Remove one or several at once (system-protected apps are shown disabled)

### 🛡️ Safety
- **Restore point** before uninstalling (optional)
- **Registry backup** before deleting any key, restorable in one click
- Leftover folders go to the **Recycle Bin** (optional)

### 🎨 Customization
- Dark, black (AMOLED) and light themes
- 8 ready-made color combos or your own colors
- Adjustable logo color

## 📥 Download

Get the latest version from the [**Releases**](https://github.com/Thiagosystems/THCleaner/releases) page.

> No installation needed: the .exe already includes .NET. Works on Windows 10/11 64-bit.
> The app asks for **administrator** permission, which is needed to clean system folders and uninstall programs.
> The interface is currently in Portuguese.

## 🛠️ Build

Requirement: [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

```bat
git clone https://github.com/Thiagosystems/THCleaner.git
cd THCleaner
build.bat
```

The executable is created at `publish\THCleaner.exe`.

## 📁 Structure

| File | Purpose |
|---|---|
| `DiskCleaner.cs` | Cleanup categories, analysis and cleaning |
| `LargeFiles.cs` | Large file search |
| `Uninstaller.cs` | Programs, uninstall, leftovers, backups and Store apps |
| `Util.cs` | Recycle Bin, commands and helpers |
| `ThemeManager.cs` | Themes and colors |
| `AppSettings.cs` | Settings (`%AppData%\THCleaner\settings.json`) |
| `MainWindow.xaml` | User interface |

## ❓ FAQ

**Some files weren't deleted. Is that normal?**
Yes. Files in use by Windows or by open programs are kept, and TH Cleaner shows how many were skipped.

**I removed something from the registry by mistake. How do I undo it?**
Go to **Backups** and click **Restaurar** (Restore). For bigger problems, use the Windows restore point created before the uninstall.

**Where are the backups stored?**
In `%AppData%\THCleaner\Backups`.

## 📄 License

Distributed under the MIT License. See [LICENSE](LICENSE).
